CREATE DATABASE catalog;
USE catalog;

CREATE TABLE products (
  id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(15),
  description VARCHAR(50),
  price DECIMAL(7,2)
);

