CREATE TABLE pizza.order (
  order_id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
  customer_id INTEGER NOT NULL,
  delivery VARCHAR(13),
  size VARCHAR(6),
  status CHAR(1) DEFAULT 'O' NOT NULL);

CREATE TABLE customer (
  customer_id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  address TEXT NOT NULL);

CREATE TABLE topping (
   order_id INTEGER NOT NULL,
   topping VARCHAR(13) NOT NULL,
   PRIMARY KEY (order_id, topping)
);