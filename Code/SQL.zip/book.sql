CREATE TABLE book (
  id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(50) NOT NULL,
  authors VARCHAR(50),
  editor VARCHAR(50),
  chapters TEXT,
  page_count INTEGER,
  status CHAR(1) NOT NULL);