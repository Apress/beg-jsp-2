INSERT INTO products (name, description, price)
         VALUES ("Widget A", "A nice entry-level widget", 5000),
         ("Widget B", "An even better widget", 5625),
         ("Widget C", "This widget is the coolest, and you need it", 6403),
         ("Widget D", "Customers of means will appreciate this widget",
          7500),
         ("Widget E", "This widget will bring you friends and popularity", 
          8950),
         ("Widget F", "We distilled happiness and made it into this widget", 
          15023),
         ("Widget G", "The widget to make you happier than a March hare", 
          35075),
         ("Widget H", "Exclusivity has a price, and it's $750", 75000);
